﻿namespace Vehicles
{
    public enum AirConditioningController
    {
        OFF,
        ON,
    }
}
