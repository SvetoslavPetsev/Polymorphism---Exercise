﻿namespace WildFarm.Foods
{
    public class Fruit : Food
    {
        
        public Fruit(string type, int quantity) 
            : base(type, quantity)
        {
        }
    }
}
