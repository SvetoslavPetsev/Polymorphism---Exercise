﻿namespace WildFarm.Foods
{
    public class Meat : Food
    {
        public Meat(string type, int quantity) 
            : base(type, quantity)
        {
        }
    }
}
