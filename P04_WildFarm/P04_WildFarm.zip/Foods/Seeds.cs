﻿namespace WildFarm.Foods
{
    public class Seeds : Food
    {
        public Seeds(string type, int quantity) 
            : base(type, quantity)
        {
        }
    }
}
