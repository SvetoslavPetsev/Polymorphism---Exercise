﻿namespace WildFarm.Foods
{
    public class Vegetable : Food
    {
        public Vegetable(string type, int quantity) 
            : base(type, quantity)
        {
        }
    }
}
