﻿namespace WildFarm.Enumerators
{
    public enum OwlFood
    {
        Meat,
    }
}
