﻿namespace WildFarm.Enumerators
{
    public enum MouseFood
    {
        Vegetable,
        Fruit,
    }
}
