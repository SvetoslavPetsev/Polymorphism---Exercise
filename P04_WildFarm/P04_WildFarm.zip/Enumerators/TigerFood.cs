﻿namespace WildFarm.Enumerators
{
    public enum TigerFood
    {
        Meat,
    }
}
