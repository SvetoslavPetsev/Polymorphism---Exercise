﻿namespace WildFarm.Enumerators
{
    public enum DogFood
    {
        Meat,
    }
}
