﻿namespace WildFarm.Enumerators
{
    public enum CatFood
    {
        Meat,
        Vegetable,
    }
}
