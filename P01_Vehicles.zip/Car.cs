﻿namespace P01.Vehicles
{
    public class Car : Vehicle
    {
        public Car(double fuelQuantity, double litersPerKilometer)
            :base(fuelQuantity, litersPerKilometer)
        {
            base.ConstReservour = 1;
            base.ClimaConsuption = 0.9;
        }
    }
}
