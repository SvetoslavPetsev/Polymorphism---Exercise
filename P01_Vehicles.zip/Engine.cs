﻿namespace P01.Vehicles
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    public class Engine
    {
        private List<Vehicle> vehicleList;
        public Engine()
        {
            this.vehicleList = new List<Vehicle>();
        }

        public void Run()
        {
            for (int i = 0; i < 2; i++)
            {
                string[] info = Console.ReadLine().Split().ToArray();
                string vehicleType = info[0];
                double fuelQuantity = double.Parse(info[1]);
                double fuelConsumption = double.Parse(info[2]);

                Vehicle vehicle = null;

                if (vehicleType == "Car")
                {
                    vehicle = new Car(fuelQuantity, fuelConsumption);
                }
                else if (vehicleType == "Truck")
                {
                    vehicle = new Truck(fuelQuantity, fuelConsumption);
                }
                vehicleList.Add(vehicle);
            }

            int n = int.Parse(Console.ReadLine());

            for (int i = 0; i < n; i++)
            {
                string[] cmdArg = Console.ReadLine().Split().ToArray();
                string command = cmdArg[0];
                string type = cmdArg[1];

                Vehicle selectedVehicle = vehicleList.FirstOrDefault(x => x.GetType().Name == type);

                if (command == "Drive")
                {
                    double distance = double.Parse(cmdArg[2]);
                    try
                    {
                        selectedVehicle.Drive(distance);
                        Console.WriteLine($"{selectedVehicle.GetType().Name} travelled {distance} km");
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                        continue;
                    }
                }
                else if (command == "Refuel")
                {
                    double fuel = double.Parse(cmdArg[2]);
                    selectedVehicle.Refuel(fuel);
                }
            }
            foreach (var vehicle in vehicleList)
            {
                Console.WriteLine(vehicle);
            }
        }
    }
}
