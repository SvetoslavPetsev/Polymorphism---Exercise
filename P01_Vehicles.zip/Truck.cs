﻿namespace P01.Vehicles
{
    using System;
    public class Truck : Vehicle
    {

        public Truck(double fuelQuantity, double litersPerKilometer)
            : base(fuelQuantity, litersPerKilometer)
        {
            base.ClimaConsuption = 1.6;
            base.ConstReservour = 0.95;
        }
    }
}
