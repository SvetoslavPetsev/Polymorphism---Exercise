﻿namespace P01.Vehicles
{
    using System;
    public class Vehicle
    {
        public Vehicle(double fuelQuantity, double litersPerKilometer)
        {
            this.FuelQuantity = fuelQuantity;
            this.LitersPerKilometer = litersPerKilometer;
            this.TraveledDistance = 0;
        }
        protected double FuelQuantity { get; set; }

        protected double LitersPerKilometer { get; set; }

        protected double FuelConsumption { get; set; }

        protected double TraveledDistance { get; set; }

        protected double ClimaConsuption { get; set; }

        protected double ConstReservour { get; set; }

        public void Drive(double distance)
        {
            double neededFuel = distance * (this.LitersPerKilometer + this.ClimaConsuption);
            if (neededFuel > this.FuelQuantity)
            {
                throw new InvalidOperationException($"{this.GetType().Name} needs refueling");
            }
            this.FuelQuantity -= neededFuel;
        }

        public void Refuel(double fuel)
        {
            this.FuelQuantity += fuel * this.ConstReservour;
        }

        public override string ToString()
        {
            return $"{this.GetType().Name}: {this.FuelQuantity:F2}";
        }
    }
}
